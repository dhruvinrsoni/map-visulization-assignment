Here is the folder as a solution to the Front End Map Visulization Assignment. 

You can host this folder on any http server and kindly open index.html file. 

Also if you have python libraries support then kindly run the following command in terminal.

/../Root$ python server.py <PORT NUMBER> 

e.g. python server.py 3000

This will host the site(open index.html) when you go to the following site:

http://localhost:<PORT NUMBER>

e.g. http://localhost:3000 OR http://localhost:3000/index.html

Kindly mail to f20150047@goa.bits-pilani.ac.in if any issues occur. 

Thank You... :)